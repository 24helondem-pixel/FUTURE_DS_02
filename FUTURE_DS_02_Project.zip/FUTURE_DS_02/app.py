import streamlit as st
import plotly.express as px
from analysis import load_data,get_kpis,churn_by
st.set_page_config(page_title="Customer Retention & Churn",page_icon="👥",layout="wide")
st.title("Customer Retention & Churn Analysis")
st.caption("Future Interns | Data Science & Analytics | Task 2")
st.info("Synthetic telecom-style dataset for demonstration; not real customer data.")
d=load_data()
with st.sidebar:
    contracts=st.multiselect("Contract",sorted(d.Contract.unique()),default=sorted(d.Contract.unique()))
    internet=st.multiselect("Internet service",sorted(d.InternetService.unique()),default=sorted(d.InternetService.unique()))
    payments=st.multiselect("Payment method",sorted(d.PaymentMethod.unique()),default=sorted(d.PaymentMethod.unique()))
f=d[d.Contract.isin(contracts)&d.InternetService.isin(internet)&d.PaymentMethod.isin(payments)]
if f.empty: st.warning("No records match filters."); st.stop()
k=get_kpis(f); a,b,c,e,g=st.columns(5)
a.metric("Customers",f"{k['customers']:,}"); b.metric("Churned",f"{k['churned']:,}"); c.metric("Retained",f"{k['retained']:,}"); e.metric("Churn rate",f"{k['churn_rate']:.1f}%"); g.metric("Retention",f"{k['retention_rate']:.1f}%")
left,right=st.columns(2)
with left:
    v=f.Churn.value_counts().rename_axis("Status").reset_index(name="Customers")
    st.plotly_chart(px.pie(v,names="Status",values="Customers",hole=.5,title="Retained vs Churned"),use_container_width=True)
with right:
    x=churn_by(f,"Contract"); st.plotly_chart(px.bar(x,x="Contract",y="Churn_Rate",title="Churn by Contract",labels={"Churn_Rate":"Churn rate (%)"}),use_container_width=True)
left,right=st.columns(2)
with left:
    x=churn_by(f,"TenureGroup"); st.plotly_chart(px.bar(x,x="TenureGroup",y="Churn_Rate",title="Churn by Tenure",labels={"Churn_Rate":"Churn rate (%)"}),use_container_width=True)
with right:
    x=churn_by(f,"PaymentMethod"); st.plotly_chart(px.bar(x,x="PaymentMethod",y="Churn_Rate",title="Churn by Payment Method",labels={"Churn_Rate":"Churn rate (%)"}),use_container_width=True)
left,right=st.columns(2)
with left:
    x=churn_by(f,"MonthlyChargeBand"); st.plotly_chart(px.bar(x,x="MonthlyChargeBand",y="Churn_Rate",title="Churn by Monthly Charges",labels={"Churn_Rate":"Churn rate (%)"}),use_container_width=True)
with right: st.plotly_chart(px.box(f,x="Churn",y="Tenure",color="Churn",title="Tenure by Churn Status"),use_container_width=True)
st.subheader("Recommendations")
st.markdown("- Support new customers early in their lifecycle.\n- Review month-to-month plans and offer suitable longer-term options.\n- Investigate billing friction and payment issues.\n- Proactively assist customers reporting technical problems.\n- Track monthly churn by cohort to evaluate retention actions.")
st.download_button("Download filtered data",f.to_csv(index=False).encode(),"filtered_customer_churn.csv","text/csv")
