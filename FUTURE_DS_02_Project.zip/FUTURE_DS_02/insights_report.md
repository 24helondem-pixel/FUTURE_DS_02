# Task 2 — Initial Churn Analysis Report

## Dataset
7,043 synthetic telecom-style customer records. This is demonstration data, not real customer information.

## KPIs
- Customers: 7,043
- Churned: 1,813
- Retained: 5,230
- Churn rate: 25.74%
- Retention rate: 74.26%
- Average monthly charges: $63.47
- Average tenure: 36.0 months

## Highest churn-rate groups in this synthetic dataset
- Contract: Month-to-month — 36.57% churn rate.\n- PaymentMethod: Electronic check — 29.38% churn rate.\n- TenureGroup: 0-6 months — 47.92% churn rate.\n- MonthlyChargeBand: Medium (41-70) — 26.69% churn rate.\n
## Recommendations
1. Improve onboarding and proactive support for early-tenure customers.
2. Review month-to-month customers for appropriate longer-term plan options.
3. Investigate billing friction and payment-method issues.
4. Offer proactive technical support to customers who need it.
5. Track churn by customer cohort monthly to evaluate retention programs.

## Limitations
The dataset is synthetic. Associations are not proof of causation. Do not present these figures as real company churn metrics.
